import math
import numpy
import numpy.random

import scipy.stats

from dateutil.relativedelta import relativedelta



# Discount curve class

class DiscountCurve(object):

    # the special __init__ method defines how to
    # construct instances of the class
    def __init__(self, today, pillar_dates, discount_factors):

        # we just store the arguments as attributes of the instance
        self.today = today
        self.pillar_dates = pillar_dates
        self.discount_factors = discount_factors

        self.log_discount_factors = [
            math.log(discount_factor)
            for discount_factor in self.discount_factors
        ]

        self.pillar_days = [
            (pillar_date - self.today).days
            for pillar_date in self.pillar_dates
        ]


    # calculates a discount factor at an arbitrary value
    # date using the data stored in the instance
    def df(self, d):

        # these remain local variables, i.e. they are only
        # available within the function to read (or write) instance
        # attributes, you always need to use the self. syntax

        d_days = (d - self.today).days

        interpolated_log_discount_factor = numpy.interp(d_days, self.pillar_days, self.log_discount_factors)

        return math.exp(interpolated_log_discount_factor)


    # calculates a forward libor rate based on the discount
    # curve data stored in the instance
    def forward_libor(self, d1, d2):

        # we use the df method of the current instance to
        # calculate the forward rate
        return (
            self.df(d1) /
            self.df(d2) - 1
        ) / ((d2  - d1).days / 365)



# an EURIBOR or LIBOR rate curve
# doesn't calculate discount factors, only interpolates forward rates

class ForwardRateCurve(object):

    # the special __init__ method defines how to
    # construct instances of the class
    def __init__(self, pillar_dates, pillar_rates):

        # we just store the arguments as attributes of the instance
        self.today = pillar_dates[0]
        self.pillar_dates = pillar_dates
        self.pillar_rates = pillar_rates

        self.pillar_days = [
            (pillar_date - self.today).days
            for pillar_date in self.pillar_dates
        ]


    # interpolates the forward rates stored in the instance
    def forward_rate(self, d):

        d_days = (d - self.today).days

        return numpy.interp(d_days, self.pillar_days, self.pillar_rates)


class OvernightIndexSwap(object):

    # this method is called to build the instance, we take some
    # data arguments and save them as attributes of self
    # n.b.: payment_dates should be a list of dates, including
    # the start date as the first element
    def __init__(self, notional, payment_dates, fixed_rate):

        self.notional = notional
        self.payment_dates = payment_dates
        self.fixed_rate = fixed_rate

    # this method takes a discount curve and calculates the NPV
    # of the floating leg using that curve
    def npv_floating_leg(self, discount_curve):

        return self.notional * (
            # self.payment_dates[0] is the start date of the swap
            discount_curve.df(self.payment_dates[0]) -

            # self.payment_dates[-1] is the last payment date of the swap
            discount_curve.df(self.payment_dates[-1])
        )

    # this method takes a discount curve and calculates the NPV of
    # the fixed leg using that curve
    def npv_fixed_leg(self, discount_curve):

        npv = 0

        # we loop from i=1 up to but not including the length of
        # the date list
        for i in range(1, len(self.payment_dates)):

            start_date = self.payment_dates[i-1]
            # we can do i-1, because the loop starts with i=1

            end_date = self.payment_dates[i]

            tau = (end_date - start_date).days / 360
            df = discount_curve.df(end_date)

            npv = npv + df * tau

        return self.notional * self.fixed_rate * npv

    # this method calculates the NPV of the OIS swap
    # n.b.: inside this method we call the other two methods of
    #       the class on the same instance 'self', using
    #       self.npv_XXX_leg(...), and we pass the discount_curve
    #       we received as an argument
    def npv(self, discount_curve):

        float_npv = self.npv_floating_leg(discount_curve)
        fixed_npv = self.npv_fixed_leg(discount_curve)

        return float_npv - fixed_npv

#class to compute fair fixed rate
class fixedrate(object):
    
    def __init__(self, start_date, nominal,
                 libor_tenor, maturity):

        self.nominal = nominal

        self.fixed_leg_dates = generate_swap_dates(
            start_date,
            maturity,
            12
        )

        self.floating_leg_dates = generate_swap_dates(
            start_date,
            maturity,
            libor_tenor
        )

    def annuity_fixed(self, discount_curve):

        a_fixed = 0

        for i in range(1, len(self.fixed_leg_dates)):
            a_fixed += discount_curve.df(self.fixed_leg_dates[i])

        return a_fixed
    
    def annuity_floating(self, discount_curve):
        
        a_floating=0
        
        for i in range(1, len(self.floating_leg_dates)):
            a_floating += discount_curve.df(self.floating_leg_dates[i])
            
        return a_floating
            
                                           
    def swap_rate(self, discount_curve, fwd_ratecurve6m):

        s = 0

        for j in range(1, len(self.floating_leg_dates)):
            F = fwd_ratecurve6m.forward_rate(
                self.floating_leg_dates[j-1]
            )

            tau = (
                self.floating_leg_dates[j] -
                self.floating_leg_dates[j-1]
            ).days / 360
            
            P = discount_curve.df(
                self.floating_leg_dates[j]
            )

            s += F * tau * P

        return s / self.annuity_fixed(discount_curve)
        
    def npv(self, discount_curve,fwd_ratecurve6m ):

        S = self.swap_rate(discount_curve, fwd_ratecurve6m)
        A = self.annuity_fixed(discount_curve)

        return self.nominal * (S - S) * A
    


#swap
class Swap(object):
    
    def __init__(self, start_date, nominal,
                 libor_tenor, maturity, fixrate):

        self.nominal = nominal
        self.fixrate=fixrate

        self.fixed_leg_dates = generate_swap_dates(
            start_date,
            maturity,
            12
        )

        self.floating_leg_dates = generate_swap_dates(
            start_date,
            maturity,
            libor_tenor
        )

    def annuity_fixed(self, discount_curve, countfix):
        
        a_fixed = 0
            
        for i in range(countfix, len(self.fixed_leg_dates)):
            a_fixed += discount_curve.df(self.fixed_leg_dates[i])

        return a_fixed
    
    def annuity_floating(self, discount_curve, countfloat):
        
        a_floating=0
        
        for i in range(countfloat, len(self.floating_leg_dates)):
            a_floating += discount_curve.df(self.floating_leg_dates[i])
            
        return a_floating
            
                                           
    def swap_rate(self, discount_curve, fwd_ratecurve6m, countfloat, countfix):

        s = 0

        for j in range(countfloat, len(self.floating_leg_dates)):
            F = fwd_ratecurve6m.forward_rate(
                self.floating_leg_dates[j-1]
            )

            tau = (
                self.floating_leg_dates[j] -
                self.floating_leg_dates[j-1]
            ).days / 360
            
            P = discount_curve.df(
                self.floating_leg_dates[j]
            )

            s += F * tau * P

        return s / self.annuity_fixed(discount_curve, countfix)
        
    def npv(self, discount_curve,fwd_ratecurve6m, countfloat, countfix ):

        S = self.swap_rate(discount_curve, fwd_ratecurve6m, countfloat, countfix)
        A = self.annuity_fixed(discount_curve, countfix)

        return self.nominal * (S - self.fixrate) * A


class InterestRateSwaption(object):

    def __init__(self, exercise_date, irs):
        self.exercise_date = exercise_date
        self.irs = irs

    def npv_bs(self, discount_curve, libor_curve, sigma):

        A = self.irs.annuity(discount_curve)
        S = self.irs.swap_rate(discount_curve, libor_curve)

        T = (self.exercise_date - discount_curve.today).days / 365

        d1 = (math.log(S/self.irs.fixed_rate) + 0.5 * sigma**2 * T) / (sigma * T**0.5)
        d2 = (math.log(S/self.irs.fixed_rate) - 0.5 * sigma**2 * T) / (sigma * T**0.5)

        npv = self.irs.notional * A * (S * scipy.stats.norm.cdf(d1) - self.irs.fixed_rate * scipy.stats.norm.cdf(d2))

        return npv

    def npv_mc(self, discount_curve, libor_curve, sigma, n_scenarios=10000):

        A = self.irs.annuity(discount_curve)
        S = self.irs.swap_rate(discount_curve, libor_curve)

        T = (self.exercise_date - discount_curve.today).days / 365

        # initialize a variable to store the discounted payoff of the swaption in each Monte Carlo scenario
        discounted_payoffs = []

        # perform the Monte Carlo simulation - loop over each scenario
        for i_scenario in range(n_scenarios):

            # simulate the swap rate in this scenario
            S_simulated = S * math.exp(-0.5 * sigma * sigma * T + sigma * math.sqrt(T) * numpy.random.normal())

            # calculate the swap NPV in this scenario
            swap_npv = self.irs.notional * (S_simulated - self.irs.fixed_rate) * A

            # add the discounted payoff of the swaption, in this scenario, to the list
            discounted_payoffs.append(max(0, swap_npv))

            # Note that this is not *strictly speaking* the correct way of calculating the
            # value, the reason being that one should calculate the swap NPV at the expiry date
            # of the swaption, apply the payoff function max(0, ...) and *then* discount from the
            # expiry date to today.
            #
            # However, it's simpler to calculate it as above and it doesn't make any difference to
            # the result, since DiscountFactor * max(0, SwapNPVAtExpiry) == max(0, DiscountFactor * SwapNPVAtExpiry).

        # calculate the NPV of the swaption by taking the average of the discounted payoffs across all the scenarios
        npv_mc = numpy.mean(discounted_payoffs)

        # calculate the Monte Carlo error estimate for 'npv_mc'
        # this will give us a 99% confidence interval for the calculated value
        npv_error = 3 * numpy.std(discounted_payoffs) / math.sqrt(n_scenarios)

        return npv_mc, npv_error


def generate_swap_dates(start_date, n_months, tenor_months=12):

    dates = []

    for n in range(0, n_months, tenor_months):
        dates.append(start_date + relativedelta(months=n))

    dates.append(start_date + relativedelta(months=n_months))

    return dates


class CreditCurve(object):

    def __init__(self, pillar_dates, pillar_ndps):

        self.pillar_dates = pillar_dates
        self.pillar_ndps = pillar_ndps

        self.pillar_days = [
            (pd - pillar_dates[0]).days
            for pd in pillar_dates
        ]

        self.log_ndps = [
            math.log(ndp)
            for ndp in pillar_ndps
        ]

    def ndp(self, value_date):

        value_days = (value_date - self.pillar_dates[0]).days

        return math.exp(
            numpy.interp(
                value_days,
                self.pillar_days,
                self.log_ndps
            )
        )

    def hazard(self, value_date):
               
        ndp_1 = self.ndp(value_date)
        ndp_2 = self.ndp(value_date + relativedelta(days=1))
        delta_t = 1.0 / 365.0
        h = -1.0 / ndp_1 * (ndp_2 - ndp_1) / delta_t
        return h


class CreditDefaultSwap(object):

    def __init__(self, notional, start_date, nyears, fixed_spread, recovery=0.4):

        self.notional = notional
        self.payment_dates = generate_swap_dates(start_date, nyears*12, 3)
        self.fixed_spread = fixed_spread
        self.recovery = recovery

    def premium_leg_npv(self, discount_curve, credit_curve):

        npv = 0

        for i in range(1, len(self.payment_dates)):
            npv += (
                self.fixed_spread *
                discount_curve.df(self.payment_dates[i]) *
                credit_curve.ndp(self.payment_dates[i])
            )

        return npv * self.notional

    def default_leg_npv(self, discount_curve, credit_curve):

        npv = 0

        d = self.payment_dates[0]

        while d <= self.payment_dates[-1]:

            npv += discount_curve.df(d) * (
                credit_curve.ndp(d) -
                credit_curve.ndp(d + relativedelta(days=1))
            )

            d += relativedelta(days=1)

        return npv * self.notional * (1 - self.recovery)

    def npv(self, discount_curve, credit_curve):

        return (
            self.default_leg_npv(discount_curve, credit_curve) -
            self.premium_leg_npv(discount_curve, credit_curve)
        )
