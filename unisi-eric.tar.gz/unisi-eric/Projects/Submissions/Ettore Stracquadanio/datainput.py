from finmarkets import DiscountCurve, OvernightIndexSwap, generate_swap_dates, ForwardRateCurve
from datetime import date
today = date(2013, 10, 31)
ois_quotes = [
    {'maturity': 1, 'rate': 0.00106},
    {'maturity': 2, 'rate': 0.00114},
    {'maturity': 3, 'rate': 0.00115},
    {'maturity': 4, 'rate': 0.00117},
    {'maturity': 5, 'rate': 0.00119},
    {'maturity': 6, 'rate': 0.00121},
    {'maturity': 7, 'rate': 0.00122},
    {'maturity': 8, 'rate': 0.00124},
    {'maturity': 9, 'rate': 0.00128},
    {'maturity': 10, 'rate': 0.00131},
    {'maturity': 11, 'rate': 0.00135},
    {'maturity': 12, 'rate': 0.00138},
    {'maturity': 15, 'rate': 0.00152},
    {'maturity': 18, 'rate': 0.00166},
    {'maturity': 21, 'rate': 0.00184},
    {'maturity': 24, 'rate': 0.00206},
    {'maturity': 36, 'rate': 0.00344},
    {'maturity': 48, 'rate': 0.00543},
    {'maturity': 60, 'rate': 0.00756},
    {'maturity': 72, 'rate': 0.00967},
    {'maturity': 84, 'rate': 0.01162},
    {'maturity': 96, 'rate': 0.0134},
    {'maturity': 108, 'rate': 0.01502},
    {'maturity': 120, 'rate': 0.01649},
    {'maturity': 132, 'rate': 0.01776},
    {'maturity': 144, 'rate': 0.01888},
    {'maturity': 180, 'rate': 0.02137},
    {'maturity': 240, 'rate': 0.02322},
    {'maturity': 300, 'rate': 0.02389},
    {'maturity': 360, 'rate': 0.02416},
]
euribor_1m = [
    {'date': date(2013, 10, 31), 'rate': 0.002},
    {'date': date(2014, 4, 30), 'rate': 0.00431709159584514},
    {'date': date(2014, 10, 30), 'rate': 0.00513437204910293},
    {'date': date(2015, 4, 30), 'rate': 0.00595155807365439},
    {'date': date(2015, 10, 30), 'rate': 0.00676883852691218},
    {'date': date(2016, 4, 30), 'rate': 0.00758611898016997},
    {'date': date(2016, 10, 30), 'rate': 0.00840339943342776},
    {'date': date(2017, 4, 30), 'rate': 0.00922058545797923},
    {'date': date(2017, 10, 30), 'rate': 0.010037865911237},
    {'date': date(2018, 4, 30), 'rate': 0.0108550519357885},
    {'date': date(2018, 10, 30), 'rate': 0.0116723323890463},
    {'date': date(2019, 4, 30), 'rate': 0.0124895184135977},
    {'date': date(2019, 10, 30), 'rate': 0.0133067988668555},
    {'date': date(2020, 4, 30), 'rate': 0.0141240793201133},
    {'date': date(2020, 10, 30), 'rate': 0.0149413597733711},
    {'date': date(2021, 4, 30), 'rate': 0.0157585457979226},
    {'date': date(2021, 10, 30), 'rate': 0.0165758262511804},
    {'date': date(2022, 4, 30), 'rate': 0.0173930122757318},
    {'date': date(2022, 10, 30), 'rate': 0.0182102927289896},
    {'date': date(2023, 4, 30), 'rate': 0.0190274787535411},
    {'date': date(2023, 10, 30), 'rate': 0.0198447592067989},
    {'date': date(2024, 4, 30), 'rate': 0.0206620396600567},
    {'date': date(2024, 10, 30), 'rate': 0.0214793201133144},
    {'date': date(2025, 4, 30), 'rate': 0.0222965061378659},
    {'date': date(2025, 10, 30), 'rate': 0.0231137865911237},
    {'date': date(2026, 4, 30), 'rate': 0.0239309726156752},
    {'date': date(2026, 10, 30), 'rate': 0.024748253068933},
    {'date': date(2027, 4, 30), 'rate': 0.0255654390934844},
    {'date': date(2027, 10, 30), 'rate': 0.0263827195467422},
    {'date': date(2028, 4, 30), 'rate': 0.0267},
]
euribor_3m = [
    {'date': date(2013, 10, 31), 'rate': 0.0035},
    {'date': date(2014, 4, 30), 'rate': 0.00431709159584514},
    {'date': date(2014, 10, 30), 'rate': 0.00513437204910293},
    {'date': date(2015, 4, 30), 'rate': 0.00595155807365439},
    {'date': date(2015, 10, 30), 'rate': 0.00676883852691218},
    {'date': date(2016, 4, 30), 'rate': 0.00758611898016997},
    {'date': date(2016, 10, 30), 'rate': 0.00840339943342776},
    {'date': date(2017, 4, 30), 'rate': 0.00922058545797923},
    {'date': date(2017, 10, 30), 'rate': 0.010037865911237},
    {'date': date(2018, 4, 30), 'rate': 0.0108550519357885},
    {'date': date(2018, 10, 30), 'rate': 0.0116723323890463},
    {'date': date(2019, 4, 30), 'rate': 0.0124895184135977},
    {'date': date(2019, 10, 30), 'rate': 0.0133067988668555},
    {'date': date(2020, 4, 30), 'rate': 0.0141240793201133},
    {'date': date(2020, 10, 30), 'rate': 0.0149413597733711},
    {'date': date(2021, 4, 30), 'rate': 0.0157585457979226},
    {'date': date(2021, 10, 30), 'rate': 0.0165758262511804},
    {'date': date(2022, 4, 30), 'rate': 0.0173930122757318},
    {'date': date(2022, 10, 30), 'rate': 0.0182102927289896},
    {'date': date(2023, 4, 30), 'rate': 0.0190274787535411},
    {'date': date(2023, 10, 30), 'rate': 0.0198447592067989},
    {'date': date(2024, 4, 30), 'rate': 0.0206620396600567},
    {'date': date(2024, 10, 30), 'rate': 0.0214793201133144},
    {'date': date(2025, 4, 30), 'rate': 0.0222965061378659},
    {'date': date(2025, 10, 30), 'rate': 0.0231137865911237},
    {'date': date(2026, 4, 30), 'rate': 0.0239309726156752},
    {'date': date(2026, 10, 30), 'rate': 0.024748253068933},
    {'date': date(2027, 4, 30), 'rate': 0.0255654390934844},
    {'date': date(2027, 10, 30), 'rate': 0.0263827195467422},
    {'date': date(2028, 4, 30), 'rate': 0.0272},
]
euribor_6m = [
    {'date': date(2013, 10, 31), 'rate': 0.005},
    {'date': date(2014, 4, 30), 'rate': 0.0058},
    {'date': date(2014, 10, 30), 'rate': 0.0066},
    {'date': date(2015, 4, 30), 'rate': 0.0074},
    {'date': date(2015, 10, 30), 'rate': 0.0082},
    {'date': date(2016, 4, 30), 'rate': 0.009},
    {'date': date(2016, 10, 30), 'rate': 0.0098},
    {'date': date(2017, 4, 30), 'rate': 0.0106},
    {'date': date(2017, 10, 30), 'rate': 0.0114},
    {'date': date(2018, 4, 30), 'rate': 0.0122},
    {'date': date(2018, 10, 30), 'rate': 0.013},
    {'date': date(2019, 4, 30), 'rate': 0.0138},
    {'date': date(2019, 10, 30), 'rate': 0.0146},
    {'date': date(2020, 4, 30), 'rate': 0.0154},
    {'date': date(2020, 10, 30), 'rate': 0.0162},
    {'date': date(2021, 4, 30), 'rate': 0.017},
    {'date': date(2021, 10, 30), 'rate': 0.0178},
    {'date': date(2022, 4, 30), 'rate': 0.0186},
    {'date': date(2022, 10, 30), 'rate': 0.0194},
    {'date': date(2023, 4, 30), 'rate': 0.0202},
    {'date': date(2023, 10, 30), 'rate': 0.021},
    {'date': date(2024, 4, 30), 'rate': 0.0218},
    {'date': date(2024, 10, 30), 'rate': 0.0226},
    {'date': date(2025, 4, 30), 'rate': 0.0234},
    {'date': date(2025, 10, 30), 'rate': 0.0242},
    {'date': date(2026, 4, 30), 'rate': 0.025},
    {'date': date(2026, 10, 30), 'rate': 0.0258},
    {'date': date(2027, 4, 30), 'rate': 0.0266},
    {'date': date(2027, 10, 30), 'rate': 0.0274},
    {'date': date(2028, 4, 30), 'rate': 0.0282},
]

basis_swaps = [
    {'nominal': 1000000, 'maturity': 12, 'first_tenor': 1, 'second_tenor': 3},
    {'nominal': 1000000, 'maturity': 12, 'first_tenor': 3, 'second_tenor': 6},
    {'nominal': 1000000, 'maturity': 12, 'first_tenor': 1, 'second_tenor': 6},
    {'nominal': 1000000, 'maturity': 24, 'first_tenor': 1, 'second_tenor': 3},
    {'nominal': 1000000, 'maturity': 24, 'first_tenor': 3, 'second_tenor': 6},
    {'nominal': 1000000, 'maturity': 24, 'first_tenor': 1, 'second_tenor': 6},
    {'nominal': 1000000, 'maturity': 60, 'first_tenor': 1, 'second_tenor': 3},
    {'nominal': 1000000, 'maturity': 60, 'first_tenor': 3, 'second_tenor': 6},
    {'nominal': 1000000, 'maturity': 60, 'first_tenor': 1, 'second_tenor': 6},
    {'nominal': 1000000, 'maturity': 90, 'first_tenor': 1, 'second_tenor': 3},
    {'nominal': 1000000, 'maturity': 90, 'first_tenor': 3, 'second_tenor': 6},
    {'nominal': 1000000, 'maturity': 90, 'first_tenor': 1, 'second_tenor': 6},
    {'nominal': 1000000, 'maturity': 120, 'first_tenor': 1, 'second_tenor': 3},
    {'nominal': 1000000, 'maturity': 120, 'first_tenor': 3, 'second_tenor': 6},
    {'nominal': 1000000, 'maturity': 120, 'first_tenor': 1, 'second_tenor': 6},
]
##############################################################
pillar_dates = [today]
swaps = []
for quote in ois_quotes:
    swap = OvernightIndexSwap(
        
        # notional - doesn't really matter what we put here
        1e6,
        
        # payment dates
        generate_swap_dates(
            today,
            quote['maturity']
        ),
        
        # the fixed rate
        0.01 * quote['rate']
        
    )
    swaps.append(swap)
    pillar_dates.append(swap.payment_dates[-1])
    
pillar_dates = sorted(pillar_dates)
n_df_vector = len(pillar_dates)
################################
def objective_function(x):
    
    curve = DiscountCurve(
        
        # today date
        today,
        
        # pillar dates
        pillar_dates,
        
        # pillar discount factors
        x
        
    )
    
    sum_sq = 0.0
    
    for swap in swaps:
        sum_sq += swap.npv(curve) ** 2
        
    return sum_sq
from scipy.optimize import minimize
x0 = [1.0 for i in range(n_df_vector)]
bounds = [(0.01, 100.0) for i in range(n_df_vector)]
# we want to constrain the first pillar discount factor = 1 (because it has pillar date = today)
bounds[0] = (1.0, 1.0)
result = minimize(objective_function, x0, bounds=bounds)

ois_curve = DiscountCurve(today, pillar_dates, result.x)
################################################################
pillar_dates_1mfwd=[]
rates_1mfwd=[]

for eur1m in euribor_1m:
    pillar_dates_1mfwd.append(eur1m['date'])
    rates_1mfwd.append(eur1m['rate'])
    

euribor_curve_1m=ForwardRateCurve(pillar_dates_1mfwd,rates_1mfwd)
################################################################
pillar_dates_3mfwd=[]
rates_3mfwd=[]

for eur3m in euribor_3m:
    pillar_dates_3mfwd.append(eur3m['date'])
    rates_3mfwd.append(eur3m['rate'])
    

euribor_curve_3m=ForwardRateCurve(pillar_dates_3mfwd,rates_3mfwd)
################################################################
pillar_dates_6mfwd=[]
rates_6mfwd=[]

for eur6m in euribor_6m:
    pillar_dates_6mfwd.append(eur6m['date'])
    rates_6mfwd.append(eur6m['rate'])
    

euribor_curve_6m=ForwardRateCurve(pillar_dates_6mfwd,rates_6mfwd)
################################################################
bs_mat=[]
bs_ft=[]
bs_st=[]
for bsw in basis_swaps:
    bs_mat.append(bsw['maturity'])
    bs_ft.append(bsw['first_tenor'])
    bs_st.append(bsw['second_tenor'])
    
    




