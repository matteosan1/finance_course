import math
import numpy


# Discount curve class

class DiscountCurve(object):
    
    # the special __init__ method defines how to construct instances of the class
    def __init__(self, today, pillar_dates, discount_factors):
        
        # we just store the arguments as attributes of the instance
        self.today = today
        self.pillar_dates = pillar_dates
        self.discount_factors = discount_factors
        
        
    # calculates a discount factor at an arbitrary value date using the data stored in the instance
    def df(self, d):
        
        # these remain local variables, i.e. they are only available within the function
        # to read (or write) instance attributes, you always need to use the self. syntax
       
        log_discount_factors = [
            math.log(discount_factor)
            for discount_factor in self.discount_factors
        ]
        
        pillar_days = [
            (pillar_date - self.today).days
            for pillar_date in self.pillar_dates
        ]
        
        d_days = (d - self.today).days
        
        interpolated_log_discount_factor = numpy.interp(d_days, pillar_days, log_discount_factors)
        
        return math.exp(interpolated_log_discount_factor) 
    
    
    # calculates a forward libor rate based on the discount curve data stored in the instance
    def forward_libor(self, d1, d2):
       
        # we use the df method of the current instance to calculate the forward rate
        return (
            self.df(d1) /
            self.df(d2) - 1
        ) / ((d2  - d1).days / 365)
